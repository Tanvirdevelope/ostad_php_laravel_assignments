-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 04:59 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_module_6`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `creation_date`) VALUES
(1, 'Desktop', '2023-11-06 19:17:20'),
(2, 'Laptop', '2023-11-06 19:17:20'),
(3, 'Monitor', '2023-11-06 19:17:39'),
(4, 'UPS', '2023-11-06 19:17:39'),
(5, 'Gadget', '2023-11-06 19:18:21');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `email`, `location`, `created_date`) VALUES
(1, 'Md. Abir', 'abir@gmail.com', 'Khulna', '2023-11-06 19:06:05'),
(2, 'Md. Miraz', 'miraz@gmail.com', 'Bagerhat', '2023-11-06 19:06:05'),
(3, 'Md. Sumon', 'sumon@gmail.com', 'Satkhira', '2023-11-06 19:11:01'),
(4, 'Sabbir hossen', 'sabbir@gmail.com', 'Gopalgange', '2023-11-06 19:11:01'),
(5, 'Amit Biswas', 'amit@gmail.com', 'Khulna', '2023-11-06 19:14:03');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total_amount` float NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `total_amount`, `order_date`) VALUES
(1, 1, 35000, '2023-11-06 19:31:05'),
(2, 2, 35000, '2023-11-06 19:31:05'),
(3, 3, 13500, '2023-11-06 19:32:02'),
(4, 4, 38000, '2023-11-06 19:32:02'),
(5, 5, 35000, '2023-11-06 19:32:28');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` float NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `product_id`, `quantity`, `unit_price`, `created_date`) VALUES
(1, 1, 1, 2, 17500, '2023-11-06 19:37:40'),
(2, 2, 1, 2, 17500, '2023-11-06 19:37:40'),
(3, 3, 2, 1, 13500, '2023-11-06 19:39:01'),
(4, 4, 3, 1, 38000, '2023-11-06 19:39:01'),
(5, 5, 5, 5, 7000, '2023-11-06 19:40:35');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `price`, `category_id`, `created_date`) VALUES
(1, 'Processor', 'Lorem Ipsum is simply dummy text of the printing', 17500, 1, '2023-11-06 19:21:05'),
(2, 'Motherboard', 'Lorem Ipsum is simply dummy text of the printing', 13500, 1, '2023-11-06 19:21:05'),
(3, 'Graphics Card', 'Lorem Ipsum is simply dummy text of the printing', 38000, 1, '2023-11-06 19:21:44'),
(4, 'Ram', 'Lorem Ipsum is simply dummy text of the printing', 4600, 1, '2023-11-06 19:23:00'),
(5, 'SSD', 'Lorem Ipsum is simply dummy text of the printing', 7000, 1, '2023-11-06 19:23:00'),
(6, 'Casing', 'Lorem Ipsum is simply dummy text of the printing', 3500, 2, '2023-11-06 21:29:49'),
(7, 'Power Supply', 'Lorem Ipsum is simply dummy text of the printing', 4000, 2, '2023-11-06 21:29:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
